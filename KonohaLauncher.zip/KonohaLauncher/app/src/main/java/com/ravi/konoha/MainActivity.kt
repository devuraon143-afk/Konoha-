package com.ravi.konoha

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin

// Naruto palette: Leaf orange, Sharingan red, Rasengan blue, Hinata lavender, Sage green, Sand gold, Chidori violet, Sakura pink
val BORDERS = intArrayOf(
    Color.parseColor("#D9631F"), Color.parseColor("#C23B2E"), Color.parseColor("#2F7DE0"), Color.parseColor("#8E7BE8"),
    Color.parseColor("#3FAE5A"), Color.parseColor("#D9A21F"), Color.parseColor("#7A4BD0"), Color.parseColor("#E0568C")
)

class AppItem(val label: String, val ri: ResolveInfo, val icon: Drawable, val style: Int)

/** Torn-scroll frame with the app icon inside and the NARUTO tag at the bottom. */
class ScrollIcon(private val app: Drawable, private val style: Int) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        c.save(); c.translate(bounds.left.toFloat(), bounds.top.toFloat())
        p.style = Paint.Style.FILL; p.color = BORDERS[style % BORDERS.size]
        c.drawRoundRect(0f, 0f, w, w, w * .09f, w * .09f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = w * .02f; p.color = Color.argb(110, 60, 20, 0)
        for (i in 0 until 14) {
            val x = w * (.04f + i * .065f)
            c.drawLine(x, w * .015f, x + w * .03f, w * .06f, p)
            c.drawLine(x, w * .985f, x + w * .03f, w * .94f, p)
        }
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#F6ECD6")
        c.drawRoundRect(w * .1f, w * .1f, w * .9f, w * .77f, w * .05f, w * .05f, p)
        app.setBounds((w * .2f).toInt(), (w * .13f).toInt(), (w * .8f).toInt(), (w * .74f).toInt())
        app.draw(c)
        p.textAlign = Paint.Align.CENTER; p.textSize = w * .14f
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.style = Paint.Style.STROKE; p.strokeWidth = w * .04f; p.color = Color.parseColor("#0E1440")
        c.drawText("NARUTO", w / 2, w * .92f, p)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#3D7BFF")
        c.drawText("NARUTO", w / 2, w * .92f, p)
        c.restore()
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("DEPRECATION") override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Konoha sunset, dark mountains, drifting leaves and Hinata-lavender petals. */
class BgView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(7)
    private val px = FloatArray(14) { rnd.nextFloat() }
    private val py = FloatArray(14) { rnd.nextFloat() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 16000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#1E1550"), Color.parseColor("#7A3AA8"), Color.parseColor("#EE5A3A"), Color.parseColor("#FFB347")),
            floatArrayOf(0f, .4f, .75f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        p.color = Color.parseColor("#55FFE9A8"); c.drawCircle(w * .75f, h * .62f, w * .26f, p)
        p.color = Color.parseColor("#CC2A1448")
        val m = Path()
        m.moveTo(0f, h); m.lineTo(0f, h * .84f); m.lineTo(w * .2f, h * .76f); m.lineTo(w * .38f, h * .82f)
        m.lineTo(w * .55f, h * .72f); m.lineTo(w * .78f, h * .8f); m.lineTo(w, h * .74f); m.lineTo(w, h); m.close()
        c.drawPath(m, p)
        for (i in px.indices) {
            val y = ((py[i] + t * (1f + (i % 3) * .4f)) % 1f) * h
            val x = px[i] * w + 24f * sin(t * 6.28f + i)
            c.save(); c.rotate(t * 360f + i * 30f, x, y)
            p.color = if (i % 2 == 0) Color.argb(170, 255, 255, 255) else Color.argb(170, 196, 189, 255)
            c.drawOval(RectF(x - 7f, y - 4f, x + 7f, y + 4f), p)
            c.restore()
        }
    }
}

/** Tap the eye to activate Byakugan. */
class ByakuganView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var on = false
    init { setOnClickListener { on = !on; invalidate() } }
    override fun onDraw(c: Canvas) {
        val m = width / 2f; val r = m - 5f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#F1EEFF"); c.drawCircle(m, m, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.parseColor("#8D86EE"); c.drawCircle(m, m, r, p)
        if (on) {
            p.strokeWidth = 3f
            for (k in 0 until 10) {
                val a = k * 36f * Math.PI.toFloat() / 180f
                c.drawLine(m + r * .45f * cos(a), m + r * .45f * sin(a), m + r * .92f * cos(a), m + r * .92f * sin(a), p)
            }
        }
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#8D86EE")
        c.drawCircle(m, m, if (on) r * .3f else r * .17f, p)
    }
}

class MainActivity : Activity() {
    private var all = listOf<AppItem>()
    private var shown = listOf<AppItem>()
    private lateinit var grid: GridView
    private lateinit var dock: LinearLayout
    private lateinit var search: EditText
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val letters = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
    private fun barH(n: String): Int {
        val id = resources.getIdentifier(n, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }
    private fun tv(sz: Float, bold: Boolean = false) = TextView(this).apply {
        setTextColor(Color.WHITE); textSize = sz
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setShadowLayer(6f, 0f, 2f, Color.argb(160, 20, 0, 40))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val sb = barH("status_bar_height"); val nb = barH("navigation_bar_height")

        val root = FrameLayout(this)
        root.addView(BgView(this), FrameLayout.LayoutParams(MATCH, MATCH))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18.dp(), sb + 10.dp(), 18.dp(), nb + 10.dp())
        }

        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = when { h < 5 -> "Raat ke Shinobi"; h < 12 -> "Ohayo"; h < 17 -> "Konnichiwa"; else -> "Konbanwa" }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextClock(this).apply {
            format12Hour = "hh:mm"; format24Hour = "HH:mm"; setTextColor(Color.WHITE); textSize = 50f
            setTypeface(Typeface.SERIF, Typeface.BOLD); setShadowLayer(8f, 0f, 3f, Color.argb(160, 20, 0, 40))
        })
        left.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMM"; format24Hour = "EEEE, d MMM"; setTextColor(Color.parseColor("#FFE9A8")); textSize = 14f
        })
        left.addView(tv(17f, true).apply { text = "$hello, Ravi sama! Dattebayo!" })
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(ByakuganView(this), LinearLayout.LayoutParams(72.dp(), 72.dp()))
        col.addView(head)

        search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(Color.argb(200, 255, 255, 255)); setTextColor(Color.WHITE)
            isSingleLine = true; textSize = 15f; setPadding(20.dp(), 10.dp(), 20.dp(), 10.dp())
            background = GradientDrawable().apply { setColor(Color.argb(80, 20, 10, 60)); cornerRadius = 26.dp().toFloat(); setStroke(2, Color.argb(120, 255, 255, 255)) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        col.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 14.dp(); bottomMargin = 10.dp() })

        grid = GridView(this).apply {
            numColumns = 4; verticalSpacing = 8.dp(); selector = ColorDrawable(0)
            setPadding(0, 0, 18.dp(), 0); clipToPadding = false; isVerticalScrollBarEnabled = false
        }
        col.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp())
            background = GradientDrawable().apply { setColor(Color.argb(90, 20, 10, 50)); cornerRadius = 30.dp().toFloat(); setStroke(2, Color.argb(120, 255, 255, 255)) }
        }
        col.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 8.dp() })
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (ch in letters) side.addView(tv(10f).apply { text = ch.toString(); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(18.dp(), 0, 1f))
        side.setOnTouchListener { v, e ->
            val i = ((e.y / v.height) * letters.length).toInt().coerceIn(0, letters.length - 1)
            jump(letters[i]); true
        }
        root.addView(side, FrameLayout.LayoutParams(WRAP, MATCH, Gravity.END).apply { topMargin = sb + 230.dp(); bottomMargin = nb + 110.dp() })
        setContentView(root)
    }

    override fun onResume() { super.onResume(); load() }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); search.setText(""); grid.setSelection(0) }
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION") override fun onBackPressed() {}

    private fun load() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it, it.loadIcon(pm), it.activityInfo.packageName.hashCode() and 0x7fffffff) }
            .sortedBy { it.label.lowercase() }
        applyFilter(search.text.toString()); buildDock()
    }

    private fun applyFilter(q: String) {
        shown = all.filter { it.label.contains(q.trim(), true) }
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int): Any = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup?): View = cell(shown[p], true)
        }
    }

    private fun jump(ch: Char) {
        val i = shown.indexOfFirst {
            val f = it.label.firstOrNull()?.uppercaseChar() ?: '#'
            if (ch == '#') !f.isLetter() else f == ch
        }
        if (i >= 0) grid.setSelection(i)
    }

    private fun buildDock() {
        dock.removeAllViews()
        val keys = listOf(listOf("phone", "dialer"), listOf("message"), listOf("chrome", "browser", "brave"), listOf("camera"))
        keys.mapNotNull { k -> all.firstOrNull { a -> k.any { a.label.lowercase().contains(it) } } }.distinct()
            .forEach { dock.addView(cell(it, false), LinearLayout.LayoutParams(0, WRAP, 1f)) }
    }

    private fun cell(a: AppItem, label: Boolean): View {
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 4.dp(), 0, 4.dp()) }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY; setImageDrawable(ScrollIcon(a.icon, a.style)) }
        ll.addView(iv, LinearLayout.LayoutParams(62.dp(), 62.dp()))
        if (label) ll.addView(tv(11f).apply { text = a.label; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 4.dp() })
        val pkg = a.ri.activityInfo.packageName
        ll.setOnClickListener {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(pkg, a.ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        }
        ll.setOnLongClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))); true
        }
        return ll
    }
}
